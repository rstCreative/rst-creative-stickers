# RST Creative Stickers

App de Android con stickers animados de RST Creative para WhatsApp.
Hecha con la plantilla oficial de WhatsApp (https://github.com/WhatsApp/stickers, licencia BSD).

## Qué incluye

- Paquete **"RST Creative"** con 3 stickers animados de 512×512 y fondo transparente:
  brazos y salto, corazón, y salto con corazón.
- Ícono del paquete (96×96) e ícono de la app con el personaje.
- Compilación automática: cada vez que subes cambios a GitHub, se genera el APK solo.

## Obtener el APK

1. Sube todo este proyecto a un repositorio de GitHub (rama `main`).
2. En la pestaña **Actions** verás "Compilar app" en marcha (tarda unos 5 minutos).
3. Cuando termine, ve a **Releases** y descarga `RST-Creative-Stickers.apk` en tu celular.
4. Instálalo (Android pedirá permitir "instalar apps desconocidas"), ábrelo y toca **Agregar a WhatsApp**.

## Agregar más stickers

1. Crea el sticker con el Sticker Studio (WebP animado de 512×512, máximo 500 KB).
2. Cópialo en `app/src/main/assets/1/`.
3. Agrégalo en `app/src/main/assets/contents.json` con 1 a 3 emojis.
4. Sube el número de `image_data_version` (por ejemplo de "1" a "2") para que WhatsApp actualice el paquete.
5. Sube los cambios a GitHub y se compila una versión nueva.

Reglas de WhatsApp: de 3 a 30 stickers por paquete, todos animados (no mezclar con estáticos),
máximo 10 segundos por sticker, y el primer frame debe mostrar el sticker completo.
Se pueden tener hasta 10 paquetes creando las carpetas `2`, `3`, etc.

## Publicar en Google Play

La app ya está lista para Google Play:
- Apunta a Android 16 (API 36), como exige Google Play desde el 31 de agosto de 2026.
- Se adapta a la pantalla de borde a borde de Android 15 y 16.
- Cada compilación sube sola el número de versión (Google Play no acepta repetirlo).
- Genera el archivo `.aab` firmado que pide Google Play.

Para que genere el `.aab` firmado, agrega 4 secretos en GitHub
(Settings → Secrets and variables → Actions → New repository secret):
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` y `KEY_PASSWORD`.
Los valores están en el archivo de la clave de firma, que se entrega aparte y
**nunca** debe subirse al repositorio.

En Google Play Console, deja activada la **firma de apps de Google Play** (Play App Signing):
Google guarda la clave final de la app y tu clave solo sirve para subir versiones.
Si algún día la pierdes, se puede reemplazar pidiéndolo al soporte de Google Play.

Pendiente en Play Console: ficha de la tienda, política de privacidad, clasificación de
contenido y la prueba cerrada (12 personas durante 14 días). No uses "WhatsApp" en el nombre
de la app; sí en la descripción, junto con la palabra clave **WAStickerApps**.
